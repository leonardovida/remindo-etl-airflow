# src/remindo_api/__init__.py
__version__ = "0.1.0"
